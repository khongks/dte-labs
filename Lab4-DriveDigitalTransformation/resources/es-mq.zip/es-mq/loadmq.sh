oc exec -it mq-demo-ibm-mq-0 -c qmgr -- runmqsc < /home/student/es-mq/mq-es_lab.mqsc
