java -jar target/es-producer.jar -n 2 -t reeferalert -f telemetry.json
