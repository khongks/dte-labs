# Confluent-Replicator Demo

I am listing down the demo details using Confluent Operator installed in OpenShift. Demo includes steps needed to setup the demo. This image shows what we are trying to demo.   
![](images/Demo_Summary.jpg)

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs.    
3. An external computer that can be used to compile and run the producer/consumer applications throughout the demo.   
4. A deployment of EventStreams (either in Cloud or OpenShift) or any other Kafka platform. For the purpose of this demo, I am using EventStreams deployed in a OpenShift environment. 
5. A mechanism for publishing messages to the topic in EventStreams. I am using curl in this demo.  
6. A Kafka Connect environment setup. Refer [here](../Kafka_Connect_Setup.md) for details.
7. A topic in EventStreams which will be replicated to Confluent.    




## Setting Up the Environment

### Getting details from EventStreams
For the purpose of this demo, I am using the "Lightweight Without Security" sample to create an instance of EventStreams.  We will need the following details:   
> 	Topic Name.   
> 	URL and Port for establishing connection.      
> 	Username / Password (or API Key / Secret ). (Not required if using "Lightweight Without Security" sample).    
> 	

### Setting up Replicator Source Connector

1. Download and install the Replicator Source Connector from [Confluent Hub.](https://www.confluent.io/hub/confluentinc/kafka-connect-replicator) 

	`oc -n confluent4 exec -ti connectors-0 -- /bin/sh`.    
	`confluent-hub install --no-prompt --component-dir /connectplugins confluentinc/kafka-connect-replicator:latest`.   



2. Restart the Connectors Pods.    
`oc -n confluent4 delete pods connectors-0 connectors-1`.   

3. Create a Replicator Source Connector from Confluent Control Center.   
	Go to Connect -> \{Connect-Cluster-Name\} -> Add Connector.  
	Choose the option to "Upload Connector Config File".   You can use the sample Connector Config file [connector\_replicator\_config.properties](./connector_replicator_config.properties).    Ensure that the status of the connector in Control Center is 'Running'.   
Also, a topic (myreplicator.replica) should have been created in the Confluent system automatically. If this is not the case, check and enable "topic.auto.create" in the [properties file](./connector_replicator_config.properties)
	
	![](images/image1.jpg)
	
	
4. Publish some messages to the topic in EventStreams. I am using curl for this demo.   
  
> curl -k -v -X POST  -H "Content-Type: text/plain" -H "Accept: application/json" https://light-insecure-ibm-es-recapi-external-default.mycluster-sng01-b3c-16x64-992844b4e64c83c3dbd5e7b5e2da5328-0000.sng01.containers.appdomain.cloud/topics/myreplicator/records -d 'First Test Message'


![](images/image2.jpg)
	
![](images/image3.jpg)


