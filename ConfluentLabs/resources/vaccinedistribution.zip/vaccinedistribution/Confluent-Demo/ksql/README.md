# Confluent ksqlDB 

I am listing down the demo details using Confluent Operator installed in OpenShift. Demo includes steps needed to setup the demo. This image shows what we are trying to demo.   
![](images/Demo_Summary.jpg)

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent. The instructions here fit well for a Confluent deployment in ROKs or Docker.    
3. An external computer that can be used to compile and run the producer/consumer applications throughout the demo.   
4. The load generator or some other tool for producing messages. Refer [here](../load_generator/README.md) for further details.
5. A topic in Confluent with a referenced Avro schema. Refer [here](../load_generator/README.md) for further details.



## ksqlDB Demo.

### Setting up ksqlDB. 

1. Enable ksqlDB schema in ksql.   
	Open the ksql-shared-config ConfigMap in the OpenShift Container Platform Console.  
	Add the following line to the ksqldb-server.properties section.    
	
	`ksql.schema.registry.url=http://172.21.26.22:80/`    
	The IP address and port are the Cluster-IP and port of the ksql-bootstrap-lb service
	`oc -n confluent4 get services schemaregistry-bootstrap-lb`.  

If the confluent is running in a Docker environment, this setting is available by default. If it has to be changed, it can be modified in the docker-compose.yml file used during the deployment of the Confluent in Docker.    
> 	KSQL\_KSQL\_SCHEMA\_REGISTRY\_URL: "http://schema-registry:8081"
	
2. Enable querying the ksqlDB from external through the Control Center web interface.    
	Open the controlcenter-shared-config ConfigMap in the OpenShift Container Platform Console.     
	Add the following line to the components.properties section.
	`confluent.controlcenter.ksql.advertised.url=http://119.81.209.19:31353/`.  
	The IP address and port are the External-IP and port of the ksql-bootstrap-lb service.  
	`oc -n confluent4 get services ksql-bootstrap-lb`.  

If the Confluent is running in a Docker environment, this can be configured in the docker-compose.yml file used during the deployment of the Confluent in Docker. 
> 	CONTROL\_CENTER\_KSQL\_KSQLDB1\_ADVERTISED\_URL: "http://DOCKER_IP:8088"

	
3. Create a ksqlDB stream.
	From the Confluent Control Center, go to ksqlDB -> Click on the ksqlDB application.  
	In the editor screen enter the command to create a stream.   
	
> 	CREATE STREAM UserData (first_name STRING, last_name STRING, country STRING, age INTEGER, height DOUBLE, weight DOUBLE, automated_email BOOLEAN) WITH (kafka_topic='UserData', value_format='AVRO');

Click on Run Query once.  Then go to Streams and the newly created stream should appear there.    
This command will create a Stream called UserData based on a Topic UserData. It also includes details of each field in the Topic that has to be imported. The schema type used is Avro. 

	
![](images/image4.jpg)





### Produce some messages using the Load Generator.  
In the Confluent Control Center, go to ksqlDB Editor screen. Enter the following query and "Run Query".   
`SELECT * from USERDATA EMIT CHANGES;`.  

From a terminal, run the Load Generator (Producer).  

> `java -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo 5 1`.   

Check if the messages are displayed in the Control Center.
![](images/image2.jpg)

### Using the ksqldb-cli to run queries. 
[Reference](https://hub.docker.com/r/confluentinc/ksqldb-cli)

We will deploy a ksqldb client in a Docker and run SQL commands from there to get data. 

Deploy and start the ksqldb-cli container.   
	`docker pull confluentinc/ksqldb-cli`  
	`docker start ksqldb-cli`  

Start the ksql CLI.  
	`docker exec -it ksqldb-cli ksql http://119.81.209.19:31353`  

Run the Load generator and produce some messages.   

![](images/image3.jpg)

Some sample commands:   
select FIRST_NAME, LAST_NAME, HEIGHT from UserData EMIT CHANGES;   
select FIRST_NAME, LAST_NAME, HEIGHT from UserData where HEIGHT > 110 EMIT CHANGES;   
select first_name, count(*) from UserData group by first_name EMIT CHANGES;   
list topics;   
list streams;   
describe <stream_name>;   


