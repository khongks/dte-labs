# Confluent - Monitoring from Control Center 

The Confluent Control Center (C3) provides many things that can be used for monitoring the platform. 

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs.    

## Setting Up Metrics in Confluent
The Confluent Control Center has to be setup to be able to receive metrics from Kafka brokers. 
Add the following to the kafka-shared-config configmap from the OpenShift Container Platform Console. Restart the Kafka pods.

> metric.reporters=io.confluent.metrics.reporter.ConfluentMetricsReporter  
confluent.metrics.reporter.bootstrap.servers=kafka:9071  
confluent.metrics.reporter.security.protocol=SASL_PLAINTEXT  
confluent.metrics.reporter.sasl.mechanism=PLAIN  
confluent.metrics.reporter.sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username="${file:/mnt/secrets/global_sasl_plain_username:username}" password="${file:/mnt/secrets/global_sasl_plain_password:password}";



## Useful statistics that can be monitored.

### Overview.  
This gives a dashboard view of the overall system.    
* Lists down the clusters monitored by the C3 and the status of each cluster.   
![](images/image1.jpg)

### Brokers.  
* Total throughput (production and consumption) for all Brokers.   
* Individual broker throughput.   
* Disk Usage.   
* ![](images/image2.jpg)

### Topics
* List of topics and partitions. 
* Lists out the throughput for each topic
* Provides details of any under replicated partitions. 
* Each topic can be further drilled down to get further information. It provides details like throughput, number of partitions, location of replicas, offsets, etc. 
![](images/image3.jpg)    


### Consumer Lags
* Consumer Lag refers to the number of messages that consumers have not consumed yet. In a healthy system, this number should be very small or close to zero. A large number would mean that the consumer is either slow in consuming or is not functioning effectively to consume messages. 
![](images/image4.jpg)


### Other system related details.
Go to Brokers -> System.   
* Disk usage.  
* Network Pool Usage - The fraction of time the network processor threads are busy. If the graph is consistently more than 70% - need to check.   
* Request Pool Usage - The fraction of time the request handler threads are busy. If the graph is consistently more than 70% - need to check.   
* Latency (Production / Consumption) - Clicking on different points of this graph will provide details like the time a request has been in queue, the time taken for processing the request, the time taken by other brokers to reply before responding to the client, etc.    


