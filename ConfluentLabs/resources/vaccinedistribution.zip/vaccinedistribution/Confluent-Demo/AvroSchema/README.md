# Confluent Avro Schema Registry

I am listing down the demo details using Confluent Operator installed in OpenShift. Demo includes steps needed to setup the demo. This image shows what we are trying to demo.   
![](images/Demo_Summary.jpg)

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs.    
3. An external computer that can be used to compile and run the producer/consumer applications throughout the demo.   
4. The load generator or some other tool for producing messages. Refer [here](../load_generator/README.md) for further details.
5. A topic in Confluent with a referenced Avro schema. Refer [here](../load_generator/README.md) for further details.



## AVRO Schema Demo.

### Produce a message that is fully compliant to Avro schema.  
In the first terminal, run the Load Generator (Producer).  

> `java -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo 1 1`.   

In the second terminal, run the Consumer.   
> `java -classpath "lib/*:" KafkaAvroJavaConsumerV3Demo`.   

![](images/image1.jpg)


### Produce a message that has a missing field.  

For, this edit the KafkaAvroLoadGeneratorV3Demo.java file and comment out the 'Last Name' field from being inserted. 

![](images/image2.jpg)

Compile and run the Load Generator again. The Producer should fail.
![](images/image3.jpg)


### Produce a message that has a missing field but with a default value.  

For, this edit the KafkaAvroLoadGeneratorV3Demo.java file and comment out the 'Country' field from being inserted.   
Compile and run the Load Generator again. The Producer and Consumer should function. The Country field should be populated with the default value.   
![](images/image4.jpg)



