# Confluent-Demo

I am listing down the demo details using Confluent Operator installed in OpenShift. Demo includes steps needed to setup the demo. 

## Pre-requsites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginers](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs.    
3. An external computer that can be used to compile and run the producer/consumer applications throughout the demo.   
4. Setup the [Load Generator](load_generator/README.md) tool that will be used as producer for most of the demos. 



## Available Demos
1. [AVRO Schema Registry](AvroSchema/README.md)
2. [Working with ksql](ksql/README.md)
3. [MQ Sink Connector](Connector_Sink_MQ/README.md)
4. [Replicator Source Connector](Connector_Source_Replicator/README.md)
5. [Monitoring Confluent](monitoring/README.md)
6. [Alerts](alert/README.md). 