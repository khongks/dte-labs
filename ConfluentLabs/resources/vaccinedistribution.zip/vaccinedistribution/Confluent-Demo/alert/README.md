# Confluent - Sending Alerts from Control Center 

The Confluent Control Center (C3) has the capabilities to monitor and send alerts. 

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs.    

## Setting Up Email Configuration in Confluent

The Confluent Control Center has to be setup to be able to send alerts. For the case of this demo, I have added Gmail setting for sending alerts. 
Add the following to the controlcenter-shared-config configmap (under email.properties) from the OpenShift Container Platform Console. Restart the Control Center pods.

> confluent.controlcenter.mail.enabled=true  
confluent.controlcenter.mail.host.name=smtp.gmail.com  
confluent.controlcenter.mail.port=587  
confluent.controlcenter.mail.from=kafka-monitor@example.com  
confluent.controlcenter.mail.username=<username>  
confluent.controlcenter.mail.password=<password / api key>  
confluent.controlcenter.mail.starttls.required=true  
confluent.controlcenter.mail.ssl.checkserveridentity=true  
confluent.controlcenter.rest.advertised.url=http://119.81.209.20:32391/



## Setup Triggers.

Click on the Alerts bell icon in the top banner. This will take us to the Alert Management page.  
Create a trigger. Sample triggers:   
* A consumer lagging behind in consuming.  
* When there are Under Replicated Partitions in the cluster.  
* Cluster Status is down.   
* Production / Consumption Latency is above a certain value.   
* Bytes in / out for specific topic is above / below certain value.    

![Sample for a consumer lagging](images/image1.jpg)

## Setup Actions
Click on the Alerts bell icon in the top banner. This will take us to the Alert Management page.    
Create an Action. While setting up the Action, pick the trigger and define the frequency and send rate for the action.   

![](images/image2.jpg)

Sample E-Mail notification.
![](images/image3.jpg)

