# Confluent-MQ Demo

I am listing down the demo details using Confluent Operator installed in OpenShift. Demo includes steps needed to setup the demo. This image shows what we are trying to demo.   
![](images/Demo_Summary.jpg)

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs.    
3. An external computer that can be used to compile and run the producer/consumer applications throughout the demo.   
4. A deployment of MQ service (either in Cloud or on-prem). For the purpose of this demo, I am using a MQ service running in IBM Cloud. 
5. The load generator or some other tool for producing messages. Refer [here](../load_generator/README.md) for further details.
6. 6. A Kafka Connect environment setup. Refer [here](../Kafka_Connect_Setup.md) for details.
7. A topic in Confluent with a referenced Avro schema. Refer [here](../load_generator/README.md) for further details.




## Setting Up the Environment

### Getting details from MQ
The following details are needed for establishing connection with MQ.
> 	Queue Manager Name.   
> 	URL and Port for establishing connection with Queue Manager.   
> 	Channel Name.  
> 	MQ Queue name.  
> 	Username / Password (or API Key / Secret ).  
> 	

### Setting up IBM MQ Sink Connector

1.	Download the latest IBM MQ Sink Connector jar file from [Github.](https://github.com/ibm-messaging/kafka-connect-mq-sink/releases/) and put it in the location where the Kafka Connect looks for plugins in the Connector Pods. This is defined by configuration parameter.  
> 	`plugin.path=/connectplugins,/usr/share/java`.   

> 	oc -n confluent exec -ti connectors-0 -- /bin/sh.  
> cd /connectplugins.  
> wget https://github.com/ibm-messaging/kafka-connect-mq-sink/releases/download/v1.3.1/kafka-connect-mq-sink-1.3.1-jar-with-dependencies.jar.     


2. Restart the Connectors Pods. 
>  `	oc -n confluent delete pods connectors-0 connectors-1`.  
> 

3. Create a MQ Sink Connector from Confluent Control Center.   
	Go to Connect -> \{Connect-Cluster-Name\} -> Add Connector.  
	Choose the option to "Upload Connector Config File".   You can use the sample Connector Config file [connector\_MQSink\_config.properties](./connector_MQSink_config.properties).    Ensure that the status of the connector in Control Center is 'Running'.   
	
	![](images/image1.jpg)
	
	
4. Use the load generator to push some contents into the Kafka topic and check MQ messages in the queue.   

> `java -classpath "lib/*:" KafkaAvroLoadGeneratorV1Demo 5 1`.   

![](images/image2.jpg)
	
![](images/image3.jpg)


