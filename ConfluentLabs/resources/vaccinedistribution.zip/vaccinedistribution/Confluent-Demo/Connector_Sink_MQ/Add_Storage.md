# Add additional PersistentVolumeClaim

This document explains how to create a PersistentVolumeClaim (PVC) and mount it to the Connectors Pods. Once done, new Connect Plugins can be installed in this PVC.


### Create a PVC
There are different ways to do this. One of it is to create the PVC from RedHat OpenShift Container Platform Console.   
![](images/image4.jpg)

Check if PVC is created and in 'Bound' state.
> `oc -n confluent4 get pvc`.   
> 

### Change ownership of the storage to provide proper access to Connector Pods.

Create a temporary POD using this [Yaml file](./chown_tool.yaml).  
Once the POD is up,

> oc -n confluent4 exec -ti chown-tool -- /bin/sh.  
> chown 1001:1001 /data  
> 

### Mount the new PVC to the Connector Pods.   

Once this is done, each time a Connector Pod is created/restarted, the PVC will be attached to it.   
This is done by modifying the Stateful Sets config of connectors. The changes can be done from  RedHat OpenShift Container Platform Console.  


	`Add Volume Mount:
	          volumeMounts:
              - name: connect-pvc-mount
                mountPath: /connectplugins
                
    Add Volume:
             volumes:
             - name: connect-pvc-mount
               persistentVolumeClaim:
                 claimName: connect-pvc

 
 ` 
Delete the Connector Pods so that, it restarts with the new PVC mounted. 
> oc -n confluent4 delete pods connectors-0 connectors-1  
 
 
