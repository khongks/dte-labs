# Load Generator

This is a tools that can be used to generate load to a Kafka topic (with or without schema registry).  The purpose of the tool is to create traffic to see metrics and monitor the traffic. It is not a suitable tool for running a performance test (load test). For performance test purposes, consider using [this](https://github.com/IBM/event-streams-sample-producer).  

## Pre-requsites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginers](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent in OpenShift. The instructions here fit well for a Confluent deployment in ROKs / Virtual machines / Physical machines.    
3. An external computer that can be used to compile and run the producer/consumer applications throughout the demo.   



## Setting up the Load Generator environment
1. Download the following to your local machine.  
	a. The com/example/customer.avsc file. This is the AVRO schema to be used.   
	b. The KafkaAvroLoadGeneratorV3Demo.java. This is the main java file that acts as a load producer.   
	c. The KafkaAvroJavaConsumerV3Demo.java. This is a sample Consumer.
	d. the files that has sample data to be populated (file1.txt, file2.txt and file3.txt).   
	e. the config.properties file that has the basic configuration about the Kafka server to be used for the demo.  
	f. Download the following libraries into the lib folder.  

		https://downloads.apache.org/avro/stable/java/avro-1.10.1.jar.  
		https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-core/2.11.3/jackson-core-2.11.3.jar.    
		https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-databind/2.11.3/jackson-databind-2.11.3.jar.    
		https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.30/slf4j-api-1.7.30.jar.  
		https://repo1.maven.org/maven2/org/slf4j/slf4j-simple/1.7.9/slf4j-simple-1.7.9.jar.  
		https://repo1.maven.org/maven2/org/apache/avro/avro-tools/1.10.1/avro-tools-1.10.1.jar.  
		http://packages.confluent.io/maven/io/confluent/kafka-json-schema-serializer/6.0.0/kafka-json-schema-serializer-6.0.0.jar.  
		http://packages.confluent.io/maven/io/confluent/kafka-schema-serializer/6.0.0/kafka-schema-serializer-6.0.0.jar.  
		http://packages.confluent.io/maven/io/confluent/kafka-schema-registry-client/6.0.0/kafka-schema-registry-client-6.0.0.jar.  
		http://packages.confluent.io/maven/io/confluent/kafka-avro-serializer/6.0.0/kafka-avro-serializer-6.0.0.jar.  
		http://packages.confluent.io/maven/org/apache/kafka/kafka-clients/6.0.0-ce/kafka-clients-6.0.0-ce.jar.  
		https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-annotations/2.11.3/jackson-annotations-2.11.3.jar.   
		https://repo1.maven.org/maven2/net/jpountz/lz4/lz4/1.3.0/lz4-1.3.0.jar.  
		https://packages.confluent.io/maven/io/confluent/monitoring-interceptors/5.5.1/monitoring-interceptors-5.5.1.jar
		
		 	
	
2. Create the java file for a the AVRO sample schema. 
> 	`java -jar lib/avro-tools-1.10.1.jar compile schema com/example/customer.avsc ./`
3. Compile the main Java Load Producer file.  
> 	`javac -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo.java`.  
4. Create a topic to be used for the test and assocoate it with the AVRO schema. This can be done from the Confluent Control Center.   
![](images/image1.jpg) 
5. Check the config.properties file. Start the load generator.  
> `java -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo <load_size> <batch>. `.  
> `<load_size> is the number of entries to be inserted into Kafka topic.`   
> `<batch> is the number of entries after which the load generator should pause for 1 second. The purpose of this to slow down the load generator while running demos. `.  
> `Sample: java -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo 1000 50`.    
 
6. Check messages being updated in the topic from Confluent Control Center.   
![](images/image2.png)

7.	Optional Step - Setting up a Kafka Consumer.    
	Compile the Consumer java file.
> `javac -classpath "lib/*:" KafkaAvroJavaConsumerV3Demo.java`.    


Run the Consumer. The Consumer will continously run mointoring any new messages in the configured topic. To stop the consumer press CTRC-C. The Consumer uses the same properties file as the Load generator.     

> `java -classpath "lib/*:" KafkaAvroJavaConsumerV3Demo`
	

