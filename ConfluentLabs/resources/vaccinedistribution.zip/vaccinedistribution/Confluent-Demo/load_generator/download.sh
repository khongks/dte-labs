curl -O https://downloads.apache.org/avro/stable/java/avro-1.10.2.jar
curl -O https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-core/2.11.3/jackson-core-2.11.3.jar
curl -O https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-databind/2.11.3/jackson-databind-2.11.3.jar
curl -O https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.30/slf4j-api-1.7.30.jar
curl -O https://repo1.maven.org/maven2/org/slf4j/slf4j-simple/1.7.9/slf4j-simple-1.7.9.jar
curl -O https://repo1.maven.org/maven2/org/apache/avro/avro-tools/1.10.2/avro-tools-1.10.2.jar
curl -O http://packages.confluent.io/maven/io/confluent/kafka-json-schema-serializer/6.0.0/kafka-json-schema-serializer-6.0.0.jar
curl -O http://packages.confluent.io/maven/io/confluent/kafka-schema-serializer/6.0.0/kafka-schema-serializer-6.0.0.jar
curl -O http://packages.confluent.io/maven/io/confluent/kafka-schema-registry-client/6.0.0/kafka-schema-registry-client-6.0.0.jar
curl -O http://packages.confluent.io/maven/io/confluent/kafka-avro-serializer/6.0.0/kafka-avro-serializer-6.0.0.jar
curl -O http://packages.confluent.io/maven/org/apache/kafka/kafka-clients/6.0.0-ce/kafka-clients-6.0.0-ce.jar
curl -O https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-annotations/2.11.3/jackson-annotations-2.11.3.jar 
mkdir lib
mv *.jar lib
