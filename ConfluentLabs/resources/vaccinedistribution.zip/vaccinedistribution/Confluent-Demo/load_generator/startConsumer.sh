java -classpath "lib/*:" KafkaAvroJavaConsumerV3Demo
