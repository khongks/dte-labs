javac -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo.java
javac -classpath "lib/*:" KafkaAvroJavaConsumerV3Demo.java
