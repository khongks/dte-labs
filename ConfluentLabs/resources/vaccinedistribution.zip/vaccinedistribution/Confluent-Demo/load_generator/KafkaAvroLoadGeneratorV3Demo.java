//package com.github.simplesteph.kafka.apps.v1;

import com.example.Customer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.List;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

public class KafkaAvroLoadGeneratorV3Demo {
    public static boolean enableschemaavro=false;
    public static boolean enableintercept=false;
    public static boolean enablemtls=false;
    public static String bootstrapServers;
    public static String sasljaas;
    public static String retries;
    public static String security;
    public static String saslmechanism;
    public static String kerberosservicename;
    public static String schemaurl;
    public static String basicauth;
    public static String basicauthuserinfo;
    public static String topic;
    public static String truststorelocation;
    public static String truststorepassword;
    public static String keystorelocation;
    public static String keystorepassword;
    public static String sslkeypassword;
    public static String schematruststorelocation;
    public static String schematruststorepassword;
    public static String intercept_bootstrapServers;
    public static String intercept_sasljaas;
    public static String intercept_security;
    public static String intercept_saslmechanism;
    private static String file1Name = "file1.txt";
    private static String file2Name = "file2.txt";
    private static String file3Name = "file3.txt";
    public static Producer<String, String> nonavroproducer;
    public static Producer<String, Customer> avroproducer;
    public static void main(String[] args) {

	List<String> file1lines = null;
	List<String> file2lines = null;
	List<String> file3lines = null;
	int loadsize = 1;
	int interval = 1;
	
       	try (InputStream input = new FileInputStream("./config.properties")) {
            Properties prop = new Properties();
            prop.load(input);
	    enableschemaavro = Boolean.parseBoolean(prop.getProperty("enableschemaavro"));
	    enableintercept = Boolean.parseBoolean(prop.getProperty("enableintercept"));
	    enablemtls = Boolean.parseBoolean(prop.getProperty("enablemtls"));
    	    bootstrapServers = prop.getProperty("bootstrap.servers");
	    sasljaas = prop.getProperty("sasl.jaas.config");
	    retries = prop.getProperty("retries");
	    security = prop.getProperty("security.protocol");
//	    truststorelocation = prop.getProperty("ssl.truststore.location");
//	    truststorepassword = prop.getProperty("ssl.truststore.password");
	    saslmechanism = prop.getProperty("sasl.mechanism");
	    topic = prop.getProperty("topic");
	    if (security.contains("SSL")){
		truststorelocation = prop.getProperty("ssl.truststore.location");
		truststorepassword = prop.getProperty("ssl.truststore.password");
	    }
	    if (enablemtls) {
		keystorelocation = prop.getProperty("ssl.keystore.location");
		keystorepassword = prop.getProperty("ssl.keystore.password");
		sslkeypassword = prop.getProperty("ssl.key.password");	
	    }
	    if ((enableschemaavro) && (security.contains("SSL"))) {
		schematruststorelocation = prop.getProperty("schema.registry.ssl.truststore.location");
                schematruststorepassword = prop.getProperty("schema.registry.ssl.truststore.password");
            }
	    if (saslmechanism.equals("GSSAPI")) {
		kerberosservicename = prop.getProperty("sasl.kerberos.service.name");
	    }
	    if (enableschemaavro) {
		schemaurl = prop.getProperty("schema.registry.url");
		basicauth = prop.getProperty("basicauth");
		basicauthuserinfo = prop.getProperty("basicauthuserinfo");
	    }
	    if (enableintercept) {
	    	intercept_bootstrapServers = prop.getProperty("intercept_bootstrapServers");
            	intercept_sasljaas = prop.getProperty("intercept_sasljaas");
            	intercept_security = prop.getProperty("intercept_security");
            	intercept_saslmechanism = prop.getProperty("intercept_saslmechanism");
	    }

       	} catch (IOException ex) {
            ex.printStackTrace();
       	}

	if (args.length < 2) {
		System.out.println("ERROR: Load Size parameter required");
		System.exit(0);
	} else {
		loadsize = Integer.parseInt(args[0]);
		interval = Integer.parseInt(args[1]);
	}

        Properties properties = new Properties();
        // normal producer
        properties.setProperty("bootstrap.servers", bootstrapServers);
        properties.setProperty("acks", "all");
        properties.setProperty("retries", retries);
	properties.setProperty("security.protocol", security);
	properties.setProperty("sasl.jaas.config", sasljaas);
	properties.setProperty("sasl.mechanism", saslmechanism);

        if (security.contains("SSL")){
        	properties.setProperty("ssl.truststore.location", truststorelocation);
        	properties.setProperty("ssl.truststore.password", truststorepassword);
		properties.setProperty("ssl.endpoint.identification.algorithm", "");
	}
        if (enablemtls) {
		properties.setProperty("ssl.keystore.location", keystorelocation);
		properties.setProperty("ssl.keystore.password", keystorepassword);
		properties.setProperty("ssl.key.password", sslkeypassword);
        }
	if ((enableschemaavro) && (security.contains("SSL"))) {
                   properties.setProperty("schema.registry.ssl.truststore.location", schematruststorelocation);
                   properties.setProperty("schema.registry.ssl.truststore.password", schematruststorepassword);
                   properties.setProperty("schema.registry.ssl.endpoint.identification.algorithm", "https");
	}
        if (saslmechanism.equals("GSSAPI")) {
		properties.setProperty("sasl.kerberos.service.name", kerberosservicename);        
        }
//	properties.setProperty("sasl.kerberos.service.name", kerberosservicename);
        // avro part
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        if (enableintercept) {
                properties.setProperty("interceptor.classes", "io.confluent.monitoring.clients.interceptor.MonitoringProducerInterceptor");
                properties.setProperty("confluent.monitoring.interceptor.security.protocol", intercept_security);
                properties.setProperty("confluent.monitoring.interceptor.sasl.mechanism", intercept_saslmechanism);
                properties.setProperty("confluent.monitoring.interceptor.sasl.jaas.config", intercept_sasljaas);
                properties.setProperty("confluent.monitoring.interceptor.bootstrap.servers", intercept_bootstrapServers);
        }
	if (enableschemaavro) {
		properties.setProperty("value.serializer", KafkaAvroSerializer.class.getName());
		properties.setProperty("key.serializer", KafkaAvroSerializer.class.getName());
        	properties.setProperty("schema.registry.url", schemaurl);
		properties.setProperty("basic.auth.credentials.source", basicauth);
		properties.setProperty("schema.registry.basic.auth.user.info", basicauthuserinfo);
		System.out.println(properties);
		avroproducer = new KafkaProducer<String, Customer>(properties);
	} else {
		properties.setProperty("value.serializer", StringSerializer.class.getName());
		properties.setProperty("key.serializer", StringSerializer.class.getName());
		nonavroproducer = new KafkaProducer<String, String>(properties);
	}

    	try {
        	file1lines = Files.readAllLines(Paths.get(file1Name),
                StandardCharsets.UTF_8);
    	} catch (IOException e) {
        	System.out.println("File can't be opened.");
    	}

        try {
                file2lines = Files.readAllLines(Paths.get(file2Name),
                StandardCharsets.UTF_8);
        } catch (IOException e) {
                System.out.println("File can't be opened.");
        }

        try {
                file3lines = Files.readAllLines(Paths.get(file3Name),
                StandardCharsets.UTF_8);
        } catch (IOException e) {
                System.out.println("File can't be opened.");
        }


        // These parameters are in Customer.java which was generated from customer.avsc
        for (int i=1; i<=loadsize; i++) { 
        int random1WordIndex = 1 + (int) (Math.random() * ((file1lines.size() - 1)));
        int random2WordIndex = 1 + (int) (Math.random() * ((file2lines.size() - 1)));
	int random3WordIndex = 1 + (int) (Math.random() * ((file3lines.size() - 1)));
//
	System.out.println("Count: " + i);
	if (enableschemaavro) {
	        Customer customer = Customer.newBuilder()
        	        .setAge((int)(Math.random() * ((80 - 1) + 1)) + 1)
                	.setFirstName(file1lines.get(random1WordIndex))
                	.setLastName(file2lines.get(random2WordIndex))
  			.setCountry(file3lines.get(random3WordIndex))
                	.setHeight((float)(Math.random() * ((170 - 60) + 1)) + 60)
                	.setWeight((float)(Math.random() * ((120 - 10) + 1)) + 10)
                	.build();

        	ProducerRecord<String, Customer> producerRecord = new ProducerRecord<String, Customer>(
                topic, customer
        	);
        	System.out.println(customer);
        	avroproducer.send(producerRecord, new Callback() {
            	@Override
            	    	public void onCompletion(RecordMetadata metadata, Exception exception) {
                	if (exception == null) {
                    		//System.out.println(metadata);
                	} else {
                    		exception.printStackTrace();
                	}
            	}
        });
	if ((interval !=0) && (i % interval == 0)) {
		try {
			System.out.println("Waiting 1 seconds");
			TimeUnit.SECONDS.sleep(1);
		} catch (InterruptedException ie) {}
	}
	} // End the enableschemaavro if

	if (!enableschemaavro) {
	String message = file1lines.get(random1WordIndex) + " " + file2lines.get(random2WordIndex) + " " + file3lines.get(random3WordIndex);  
	System.out.println(message);
        try {
          	nonavroproducer.send(new ProducerRecord<String, String>(topic,"",message));
        } catch (Exception ex) {
                ex.printStackTrace();
        }
        if ((interval !=0) && (i % interval == 0)) {
                try {
                        System.out.println("Waiting 1 seconds");
                        TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException ie) {}
        }

	} // End if NOT enableschemaavro

	}//end for loop
	if (enableschemaavro) {
        	avroproducer.flush();
        	avroproducer.close();
	}
	if (!enableschemaavro) {
		nonavroproducer.flush();
		nonavroproducer.close();
	}
    }
}
