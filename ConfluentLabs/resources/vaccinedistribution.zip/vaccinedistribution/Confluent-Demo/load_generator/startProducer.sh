java -classpath "lib/*:" KafkaAvroLoadGeneratorV3Demo $*
