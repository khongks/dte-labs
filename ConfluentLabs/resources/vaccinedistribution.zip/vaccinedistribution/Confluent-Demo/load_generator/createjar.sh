java -jar lib/avro-tools-1.10.1.jar compile schema com/example/customer.avsc ./
