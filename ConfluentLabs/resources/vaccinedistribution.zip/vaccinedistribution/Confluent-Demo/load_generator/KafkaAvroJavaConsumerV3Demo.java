//package com.github.simplesteph.kafka.apps.v1;

import com.example.Customer;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.Collections;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class KafkaAvroJavaConsumerV3Demo {
    public static boolean enableschemaavro=false;
    public static boolean enableintercept=false;
    public static boolean enablemtls=false;
    public static String bootstrapServers;
    public static String sasljaas;
//    public static String retries;
    public static String security;
    public static String saslmechanism;
    public static String kerberosservicename;
    public static String schemaurl;
    public static String basicauth;
    public static String basicauthuserinfo;
    public static String topic;
    public static String schematruststorelocation;
    public static String schematruststorepassword;
    public static String intercept_bootstrapServers;
    public static String intercept_sasljaas;
    public static String intercept_security;
    public static String intercept_saslmechanism;
    public static String truststorelocation;
    public static String truststorepassword;
    public static String keystorelocation;
    public static String keystorepassword;
    public static String sslkeypassword;
    public static KafkaConsumer<String, Customer> avroConsumer;
    public static KafkaConsumer<String, String> nonavroConsumer;

    public static void main(String[] args) {
	int count = 1;
       	try (InputStream input = new FileInputStream("./config.properties")) {
            Properties prop = new Properties();
            prop.load(input);
            enableschemaavro = Boolean.parseBoolean(prop.getProperty("enableschemaavro"));
            enableintercept = Boolean.parseBoolean(prop.getProperty("enableintercept"));
    	    bootstrapServers = prop.getProperty("bootstrap.servers");
	    sasljaas = prop.getProperty("sasl.jaas.config");
//	    retries = prop.getProperty("retries");
	    security = prop.getProperty("security.protocol");
	    saslmechanism = prop.getProperty("sasl.mechanism");
	    topic = prop.getProperty("topic");
	    if (security.contains("SSL")){
                truststorelocation = prop.getProperty("ssl.truststore.location");
                truststorepassword = prop.getProperty("ssl.truststore.password");
            }
            if (enablemtls) {
                keystorelocation = prop.getProperty("ssl.keystore.location");
                keystorepassword = prop.getProperty("ssl.keystore.password");
                sslkeypassword = prop.getProperty("ssl.key.password");
            }
            if ((enableschemaavro) && (security.contains("SSL"))) {
                schematruststorelocation = prop.getProperty("schema.registry.ssl.truststore.location");
                schematruststorepassword = prop.getProperty("schema.registry.ssl.truststore.password");
            }
            if (saslmechanism.equals("GSSAPI")) {
                kerberosservicename = prop.getProperty("sasl.kerberos.service.name");
            }
            if (enableschemaavro) {
                schemaurl = prop.getProperty("schema.registry.url");
                basicauth = prop.getProperty("basicauth");
                basicauthuserinfo = prop.getProperty("basicauthuserinfo");
            }
	    if (enableintercept) {
                intercept_bootstrapServers = prop.getProperty("intercept_bootstrapServers");
                intercept_sasljaas = prop.getProperty("intercept_sasljaas");
                intercept_security = prop.getProperty("intercept_security");
                intercept_saslmechanism = prop.getProperty("intercept_saslmechanism");
            }

       	} catch (IOException ex) {
            ex.printStackTrace();
       	}

        Properties properties = new Properties();
        // normal consumer
        properties.setProperty("bootstrap.servers",bootstrapServers);
	properties.setProperty("security.protocol", security);
	properties.setProperty("sasl.jaas.config", sasljaas);
	properties.setProperty("sasl.mechanism", saslmechanism);
        properties.put("group.id", "customer-consumer-group-v1");
        properties.put("auto.commit.enable", "false");
        properties.put("auto.offset.reset", "earliest");
        if (security.contains("SSL")){
                properties.setProperty("ssl.truststore.location", truststorelocation);
                properties.setProperty("ssl.truststore.password", truststorepassword);
		properties.put("ssl.endpoint.identification.algorithm", "");
        }
        if (enablemtls) {
                properties.setProperty("ssl.keystore.location", keystorelocation);
                properties.setProperty("ssl.keystore.password", keystorepassword);
                properties.setProperty("ssl.key.password", sslkeypassword);
        }
        if ((enableschemaavro) && (security.contains("SSL"))) {
                   properties.setProperty("schema.registry.ssl.truststore.location", schematruststorelocation);
                   properties.setProperty("schema.registry.ssl.truststore.password", schematruststorepassword);
                   properties.setProperty("schema.registry.ssl.endpoint.identification.algorithm", "https");
        }
        if (saslmechanism.equals("GSSAPI")) {
                properties.setProperty("sasl.kerberos.service.name", kerberosservicename);
        }
        // avro part (deserializer)
        properties.setProperty("key.deserializer", StringDeserializer.class.getName());



        if (enableintercept) {
                properties.setProperty("interceptor.classes", "io.confluent.monitoring.clients.interceptor.MonitoringProducerInterceptor");
                properties.setProperty("confluent.monitoring.interceptor.security.protocol", intercept_security);
                properties.setProperty("confluent.monitoring.interceptor.sasl.mechanism", intercept_saslmechanism);
                properties.setProperty("confluent.monitoring.interceptor.sasl.jaas.config", intercept_sasljaas);
                properties.setProperty("confluent.monitoring.interceptor.bootstrap.servers", intercept_bootstrapServers);
        }
        if (enableschemaavro) {
                properties.setProperty("value.deserializer", KafkaAvroDeserializer.class.getName());
                properties.setProperty("key.deserializer", KafkaAvroDeserializer.class.getName());
                properties.setProperty("schema.registry.url", schemaurl);
                properties.setProperty("basic.auth.credentials.source", basicauth);
                properties.setProperty("schema.registry.basic.auth.user.info", basicauthuserinfo);
		properties.setProperty("specific.avro.reader", "true");
		avroConsumer = new KafkaConsumer<String, Customer>(properties);
		avroConsumer.subscribe(Collections.singleton(topic));
        } else {
                properties.setProperty("value.deserializer", StringDeserializer.class.getName());
                properties.setProperty("key.deserializer", StringDeserializer.class.getName());
		nonavroConsumer = new KafkaConsumer<String, String>(properties);
		nonavroConsumer.subscribe(Collections.singleton(topic));
        }
	
//        KafkaConsumer<String, Customer> kafkaConsumer = new KafkaConsumer<>(properties);
//        String topic = "new_avro";
//        kafkaConsumer.subscribe(Collections.singleton(topic));

//        System.out.println("Waiting for data...");

        while (true){
            System.out.println("Polling");
	    if (enableschemaavro) {
            	ConsumerRecords<String, Customer> records = avroConsumer.poll(Duration.ofMillis(1000));

            	for (ConsumerRecord<String, Customer> record : records){
                	Customer customer = record.value();
			System.out.println("Count: " + count);
                	System.out.println(customer);
			count=count+1;  
            	}
	
            	avroConsumer.commitSync();
	    }
	    if (!enableschemaavro) {
		ConsumerRecords<String, String> records = nonavroConsumer.poll(Duration.ofMillis(3000L));
		for (ConsumerRecord<String, String> record : records) {
                        System.out.println("Count: " + count);
                        System.out.println(record.value());
                        count=count+1;
                }
	    }//end if
        }
    }
}
