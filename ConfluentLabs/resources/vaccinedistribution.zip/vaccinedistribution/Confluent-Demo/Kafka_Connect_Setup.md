# Kafka Connect Setup

In this document, I am listing down the steps to get a Kafka Connect environment ready for deploying connectors in a Confluent platform. 

## Prerequisites

1. Need to have some basic understanding about Kafka. You can check this for some basics:  
[Kafka for Beginners](https://yourlearning.ibm.com/activity/UDEMY-2720818)  

2. An installation of Confluent. The instructions here fit well for a Confluent deployment in ROKs or in Docker.      


## Setting Up Connect - Confluent in ROKs.
1. Check the location where the Kafka Connect looks for plugins in the Connector Pods. This is defined by configuration parameter in the Connector-Shared configmap.  


> 	`plugin.path=/connectplugins,/usr/share/java`.   
> 
* In a typical scenario, it is necessary to create a persistent storage where the plugins can be installed. Refer to [Add_Storage](./Add_Storage.md) on how to add a new PVC to the Connector Pod. 

2. New Plugins/Connectors should be installed using one of the following 2 methods.   

### For Connectors available in Confluent Hub:   
	
> 	`oc -n confluent exec -ti connectors-0 -- /bin/sh.    `
> 	`confluent-hub install --no-prompt --component-dir \<PLUGIN\_PATH\> \<PLUGIN\_NAME\> `.  
> 	`Example:`.  
> 	`confluent-hub install --no-prompt --component-dir /connectplugins confluentinc/kafka-connect-replicator:latest`
> 

### For Connectors not available in Confluent Hub:
	
> 	`oc -n confluent exec -ti connectors-0 -- /bin/sh.  `.  
> `cd /connectplugins.  `.  
> `wget https://github.com/ibm-messaging/kafka-connect-mq-sink/releases/download/v1.3.1/kafka-connect-mq-sink-1.3.1-jar-with-dependencies.jar.     `

3. Restart the Connectors Pods.    
  `	oc -n confluent delete pods connectors-0 connectors-1`.  
 

## Setting Up Connect - Confluent in Docker

Please note that by default, the containers do not have any persistent storage. Any connectors addded will be deleted when the container is deleted.    

1. 	Check the docker-compose.yml file for the location where the Kafka Connect looks for plugins in the Connector container. This is defined by configuration parameter.  
> 	`CONNECT_PLUGIN_PATH: "/usr/share/java,/usr/share/confluent-hub-components"`.   

2. New Plugins/Connectors should be installed using one of the following 2 methods.   

### For Connectors available in Confluent Hub:   
>  `docker exec -ti connect /bin/sh	 `.  
>  `confluent-hub install --no-prompt --component-dir \<PLUGIN\_PATH\> \<PLUGIN\_NAME\>.  `          
> 	`Example:`.  
> 	`confluent-hub install --no-prompt --component-dir /usr/share/confluent-hub-components confluentinc/kafka-connect-replicator:latest`.  

### For Connectors not available in Confluent Hub:
> 	`docker exec -ti connect /bin/sh.  `.   
> `cd /usr/share/confluent-hub-components/  `.   
> `wget https://github.com/ibm-messaging/kafka-connect-mq-sink/releases/download/v1.3.1/kafka-connect-mq-sink-1.3.1-jar-with-dependencies.jar.  `   

3. Restart the Connector Container.    
  `docker-compose stop connect`.  
  `docker-compose start connect`.  
  
  








