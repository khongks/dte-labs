#!/bin/bash

export QMname=00qmmi
export QMpre=mq00
export MQCCDTURL='/home/ibmuser/MQonCP4I-master/resources/cp4i2020.2/multiinstance.ibmcloud/test/ccdt.json'
export MQSSLKEYR='/home/ibmuser/MQonCP4I-master/resources/cp4i2020.2/multiinstance.ibmcloud/test/key'

echo "Starting amqsghac" $QMname
/opt/mqm/samp/bin/amqsghac APPQ $QMname

