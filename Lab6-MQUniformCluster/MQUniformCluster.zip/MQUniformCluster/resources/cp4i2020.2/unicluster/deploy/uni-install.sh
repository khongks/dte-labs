#! /bin/bash

export TARGET_NAMESPACE=mq
export QMpre=mq99
export QMnamea=mq99a
export CONNAMEa=mq99a-ibm-mq
export SERVICEa=mq99a-ibm-mq
export CHANNELa=mq99chla
export TOCLUSa=TO_UNICLUS_mq99a
export QMnameb=mq99b
export CONNAMEb=mq99b-ibm-mq
export SERVICEb=mq99b-ibm-mq
export CHANNELb=mq99chlb
export TOCLUSb=TO_UNICLUS_mq99b
export QMnamec=mq99c
export CONNAMEc=mq99c-ibm-mq
export SERVICEc=mq99c-ibm-mq
export CHANNELc=mq99chlc
export TOCLUSc=TO_UNICLUS_mq99c
export UNICLUS=UNICLUS99

( echo "cat <<EOF" ; cat unicluster.yaml_template ; echo EOF ) | sh > unicluster.yaml

oc apply -f unicluster.yaml  -n $TARGET_NAMESPACE
