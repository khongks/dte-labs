#! /bin/bash

export TARGET_NAMESPACE=mq
export QMpre=mq99
export QMnamea=mq99a
export CONNAMEa=mq99a-ibm-mq
export SERVICEa=mq99a-ibm-mq
export CHANNELa=mq99chla
export TOCLUSa=TO_UNICLUS_mq99a
export QMnameb=mq99b
export CONNAMEb=mq99b-ibm-mq
export SERVICEb=mq99b-ibm-mq
export CHANNELb=mq99chlb
export TOCLUSb=TO_UNICLUS_mq99b
export QMnamec=mq99c
export CONNAMEc=mq99c-ibm-mq
export SERVICEc=mq99c-ibm-mq
export CHANNELc=mq99chlc
export TOCLUSc=TO_UNICLUS_mq99c
export QMnamed=mq99d
export CONNAMEd=mq99d-ibm-mq
export SERVICEd=mq99d-ibm-mq
export CHANNELd=mq99chld
export TOCLUSd=TO_UNICLUS_mq99d
export UNICLUS=UNICLUS99

oc delete secret $QMpre-uniform-cluster-cert -n $TARGET_NAMESPACE
oc delete queuemanager $QMnamea -n $TARGET_NAMESPACE
oc delete route mq-traffic-mq-$QMnamea-ibm-mq-qm -n $TARGET_NAMESPACE
oc delete configmap $QMnamea-uniform-cluster-mqsc-1 -n $TARGET_NAMESPACE
oc delete configmap $QMnamea-uniform-cluster-ini-1 -n $TARGET_NAMESPACE
oc delete pvc data-$QMnamea-ibm-mq-0 -n $TARGET_NAMESPACE
oc delete pvc $QMnamea-ibm-mq-persisted-data -n $TARGET_NAMESPACE
oc delete pvc $QMnamea-ibm-mq-recovery-logs -n $TARGET_NAMESPACE
oc delete queuemanager $QMnameb -n $TARGET_NAMESPACE
oc delete route mq-traffic-mq-$QMnameb-ibm-mq-qm -n $TARGET_NAMESPACE
oc delete configmap $QMnameb-uniform-cluster-mqsc-2 -n $TARGET_NAMESPACE
oc delete configmap $QMnameb-uniform-cluster-ini-2 -n $TARGET_NAMESPACE
oc delete pvc data-$QMnameb-ibm-mq-0 -n $TARGET_NAMESPACE
oc delete pvc $QMnameb-ibm-mq-persisted-data -n $TARGET_NAMESPACE
oc delete pvc $QMnameb-ibm-mq-recovery-logs -n $TARGET_NAMESPACE
oc delete queuemanager $QMnamec -n $TARGET_NAMESPACE
oc delete route mq-traffic-mq-$QMnamec-ibm-mq-qm -n $TARGET_NAMESPACE
oc delete configmap $QMnamec-uniform-cluster-mqsc-3 -n $TARGET_NAMESPACE
oc delete configmap $QMnamec-uniform-cluster-ini-3 -n $TARGET_NAMESPACE
oc delete pvc data-$QMnamec-ibm-mq-0 -n $TARGET_NAMESPACE
oc delete pvc $QMnamec-ibm-mq-persisted-data -n $TARGET_NAMESPACE
oc delete pvc $QMnamec-ibm-mq-recovery-logs -n $TARGET_NAMESPACE
oc delete queuemanager $QMnamed -n $TARGET_NAMESPACE
oc delete route mq-traffic-mq-$QMnamed-ibm-mq-qm -n $TARGET_NAMESPACE
oc delete configmap $QMnamed-uniform-cluster-mqsc-3 -n $TARGET_NAMESPACE
oc delete configmap $QMnamed-uniform-cluster-ini-3 -n $TARGET_NAMESPACE
oc delete pvc data-$QMnamed-ibm-mq-0 -n $TARGET_NAMESPACE
oc delete pvc $QMnamed-ibm-mq-persisted-data -n $TARGET_NAMESPACE
oc delete pvc $QMnamed-ibm-mq-recovery-logs -n $TARGET_NAMESPACE
