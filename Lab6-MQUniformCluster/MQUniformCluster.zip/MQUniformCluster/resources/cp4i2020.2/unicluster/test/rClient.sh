#!/bin/bash

export QMpre=mq00
export QMname=mq00a

export MQCHLLIB='/home/ibmuser/MQonCP4I-master/resources/cp4i2020.2/unicluster/test'
export MQCHLTAB='/home/ibmuser/MQonCP4I-master/resources/cp4i2020.2/unicluster/test/ccdt2.json'
export MQAPPLNAME='MY.GETTER.APP'
export MQCCDTURL='/home/ibmuser/MQonCP4I-master/resources/cp4i2020.2/unicluster/test/ccdt2.json'
export MQSSLKEYR='/home/ibmuser/MQonCP4I-master/resources/cp4i2020.2/unicluster/test/key'


CCDT_NAME=${2:-"*ANY_QM"}

for (( i=0; i<=5; ++i)); do
  echo "Starting amqsghac" $CCDT_NAME
  /opt/mqm/samp/bin/amqsghac APPQ $CCDT_NAME &
done
